package dao;
// 대이터 생성역활 --> DB에서 데이터 가져오기

import java.util.ArrayList;
import java.util.List;

import dto.Product;

public class ProductRepository {
	private List<Product> listOfProducts = 
			new ArrayList<Product>();

	public ProductRepository() {
		super();
		// 제품 3개 생성
		Product phone = new Product("P1234", "아이폰", 
				"1200000", "아이폰15 256m", "애플", "휴대폰", 100, "새상품","P1234.png");
		listOfProducts.add(phone);
		Product noteBook = new Product("P1235", "LG그램", 
				"2200000", "엘지그램 입니다.", "엘지", "노트북", 500, "새상품","P1235.png");
		listOfProducts.add(noteBook);
		Product gelectTab = new Product("P1236", "갤럭시 탭", 
				"3200000", "겔럭시 고 사양", "삼성", "탭", 2000, "새상품","P1236.png");
		listOfProducts.add(gelectTab);	
		
	}
	public List<Product> getAllProducts(){
		return listOfProducts;
	}
	
	public Product getProductByID(String id) {
		for (Product product : listOfProducts) {
			if(product.getProductID().equals(id))
				return product;
		}
		return null;
	}
	
	
	
	
}

package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Question;
import com.example.demo.service.AnswerService;
import com.example.demo.service.DataNotFoundException;
import com.example.demo.service.QuestionService;

import lombok.RequiredArgsConstructor;


@Controller
@RequestMapping("/answer")
@RequiredArgsConstructor
public class AnswerController {

	private final AnswerService answerService;
	private final QuestionService questionService;
	
	@PostMapping("/reply/{id}")
	public String reply(@PathVariable("id") int id, 
			@RequestParam("content") String content) {
		
		try {
			Question question = questionService.findById(id);
			answerService.insert(question,content);
		} catch (DataNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "redirect:/question/detail/"+id;
	}
	
}

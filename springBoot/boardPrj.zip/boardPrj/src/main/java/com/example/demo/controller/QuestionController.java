package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entity.Question;
import com.example.demo.repository.QuestionRepository;
import com.example.demo.service.DataNotFoundException;
import com.example.demo.service.QuestionService;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
@RequestMapping("/question")
@RequiredArgsConstructor  // final이 붙은 의존객체의 생성자를 통해 의존객체를 주입
public class QuestionController {
//	@Autowired   // getter setter 통해서 의존객체를 주입  
	private final QuestionService questionService;
		
	
	@GetMapping("/list")
	public String getMethodName(Model model) {
		List<Question> qlists = questionService.findAll();
		model.addAttribute("qlists",qlists);
		return "question_list";
	}
	
	@GetMapping("/detail/{id}")
	public String detail(Model model, @PathVariable("id") int id) {
		Question question = null;
		try {
			question =  questionService.findById(id);
		} catch (DataNotFoundException e) {
			e.printStackTrace();
		}
		model.addAttribute("question", question);
		return "question_detail";
	}
	
	
	
}

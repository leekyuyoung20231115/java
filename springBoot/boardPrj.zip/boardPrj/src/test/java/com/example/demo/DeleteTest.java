package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Question;
import com.example.demo.repository.QuestionRepository;

@SpringBootTest
public class DeleteTest {

	@Autowired
	private QuestionRepository questionRepository;
	
	@Test
	public void deleteTest() {
		questionRepository.deleteById(1);
		List<Question> all = questionRepository.findAll();
		assertEquals(1, all.size());
	}
}

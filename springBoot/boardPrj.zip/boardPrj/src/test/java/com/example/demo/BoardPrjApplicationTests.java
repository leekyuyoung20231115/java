package com.example.demo;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Question;
import com.example.demo.repository.QuestionRepository;

@SpringBootTest
class BoardPrjApplicationTests {
	@Autowired
	private QuestionRepository questionRepository; 
	
	@Test
	void test1() {
		Question q = new Question();
		q.setSubject("질문1");
		q.setContent("jpa가 뭔가요... ");
		q.setCreateDate(LocalDateTime.now());
		questionRepository.save(q);
		
		Question q2 = new Question();
		q2.setSubject("질문2");
		q2.setContent("스프링 부트가 뭔가요... ");
		q2.setCreateDate(LocalDateTime.now());
		questionRepository.save(q2);
	}
	

}

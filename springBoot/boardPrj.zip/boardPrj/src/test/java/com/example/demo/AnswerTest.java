package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Answer;
import com.example.demo.entity.Question;
import com.example.demo.repository.AnswerRepository;
import com.example.demo.repository.QuestionRepository;

@SpringBootTest
public class AnswerTest {
	@Autowired
	private AnswerRepository answerRepository;
	@Autowired
	private QuestionRepository questionRepository;
	
	@Test
	void createAnswer() 
	{
		Optional<Question> o = questionRepository.findById(2);
		Question q =  o.get();
		
		Answer a = new Answer();
		a.setContent("스프링부트는 스프링부트입니다.");
		a.setQuestion(q);
		a.setCreateDate(LocalDateTime.now());
		answerRepository.save(a);
	}
	@Test
	void findAnswer() 
	{
		Optional<Answer> o = answerRepository.findById(1);
		Answer a =  o.get();
		assertEquals(2, a.getQuestion().getId());
	}
}

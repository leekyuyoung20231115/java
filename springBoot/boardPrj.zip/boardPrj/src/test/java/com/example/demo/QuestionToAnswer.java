package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Question;
import com.example.demo.repository.QuestionRepository;

import jakarta.transaction.Transactional;

@SpringBootTest
public class QuestionToAnswer {

	@Autowired
	private QuestionRepository questionRepository;
	
	@Test
	@Transactional
	public void testQuestionAnswer() {
		Optional<Question> o =  questionRepository.findById(2);
		Question q =  o.get();
		assertEquals("스프링부트는 스프링부트입니다.", q.getAnswerLists().get(0).getContent());
	}
}

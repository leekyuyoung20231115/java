package com.example.demo;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Question;
import com.example.demo.repository.QuestionRepository;

@SpringBootTest
public class ModifyTest {
	@Autowired
	private QuestionRepository questionRepository;
	
	@Test
	public void modifyTest() {
		Optional<Question> q = questionRepository.findById(1);
		Question qq =  q.get();
		qq.setSubject(qq.getSubject()+"0");
		questionRepository.save(qq);
	}
}

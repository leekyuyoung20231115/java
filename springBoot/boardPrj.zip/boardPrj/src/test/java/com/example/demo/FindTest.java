package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Question;
import com.example.demo.repository.QuestionRepository;

@SpringBootTest
public class FindTest {
	@Autowired
	private QuestionRepository questionRepository;
	
	@Test
	public void testFindAll() {
		List<Question>lists =  questionRepository.findAll();
		assertEquals(2, lists.size() );
	}
	
	@Test
	public void testFindById() {
		Optional<Question> o = questionRepository.findById(1);
		Question q =  o.get();
		assertNotNull(q);		
	}
	
	@Test
	public void testFindBySubject() {
		Question  q = questionRepository.findBySubject("질문1");
		assertEquals("jpa가 뭔가요... ", q.getContent());		
	}
	
	@Test
	public void findBySubjectAndContent() {
		Question  q  = questionRepository.findBySubjectAndContent("질문1", "jpa가 뭔가요... ");
		assertEquals(1, q.getId());	
		
	}
	/**
	 * And
	 * Or
	 * Between
	 * LassThan  작다
	 * GreaterThanEqual 크거나 같다
	 * In
	 * Like
	 * OrderBy
	 */
	
	@Test
	public void findbySubjectLike() {
		List<Question>  q  = questionRepository.findBySubjectLike("%질문%");
		assertEquals(2, q.size());
	}
	
}

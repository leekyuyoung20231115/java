package com.office.library.book.user;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.office.library.book.BookVo;
import com.office.library.book.RentalBookVo;

@Component
public class UserBookDao {

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	public List<BookVo> searchBookConfirm(String b_name) {
		return sqlSessionTemplate.selectList("userbook.searchbook", b_name);
	}
	public BookVo bookDetail(int b_no) {		
		return sqlSessionTemplate.selectOne("userbook.selectDetail", b_no);
	}

}

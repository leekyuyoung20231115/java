package com.office.library.book.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.office.library.book.BookVo;
import com.office.library.book.RentalBookVo;

@Controller
@RequestMapping("/book/user")
public class UserBookController {
	@Autowired
	UserBookService userBookService;
	// 도서 검색
	@GetMapping("/searchBookConfirm")
	public String searchBookConfirm(Model model,
			@RequestParam("b_name") String b_name  ) {
		
		List<BookVo> bookVos = userBookService.searchBookConfirm(b_name);
		
		model.addAttribute("bookVos", bookVos);
		return "/user/book/search_book";
	}
	// 검색된 도서 상세보기
	@GetMapping("/bookDetail")
	public String bookDetail(Model model, 
			@RequestParam("b_no") int b_no ) {
		BookVo bookVo = userBookService.bookDetail(b_no);
		model.addAttribute("bookVo", bookVo);
		return "/user/book/book_detail";
	}

}

package com.office.library.book.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.office.library.book.BookVo;
import com.office.library.book.RentalBookVo;

@Service
public class UserBookService {
	@Autowired
	UserBookDao userBookDao;
	
	public List<BookVo> searchBookConfirm(String b_name) {		
		return userBookDao.searchBookConfirm(b_name);
	}

	public BookVo bookDetail(int b_no) {		
		return userBookDao.bookDetail(b_no);
	}

}

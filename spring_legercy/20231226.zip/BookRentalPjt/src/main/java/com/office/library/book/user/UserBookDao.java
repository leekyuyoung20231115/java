package com.office.library.book.user;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.office.library.book.BookVo;
import com.office.library.book.HopeBookVo;
import com.office.library.book.RentalBookVo;
import com.office.library.book.admin.RentalBooksVo;

@Component
public class UserBookDao {

	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	public List<BookVo> searchBookConfirm(String b_name) {
		return sqlSessionTemplate.selectList("userbook.searchbook", b_name);
	}
	public BookVo bookDetail(int b_no) {		
		return sqlSessionTemplate.selectOne("userbook.selectDetail", b_no);
	}
	public int rentalBookConfirm(int b_no) {		
		return sqlSessionTemplate.update("userbook.updateRental", b_no);
	}
	public int insertRentalBook(Map<String, Integer> map) {		
		return sqlSessionTemplate.insert("rental.insert", map);
	}
	public List< Map<String, String> > enterBookshelf(int u_m_no) {
		return sqlSessionTemplate.selectList("rental.select",u_m_no);		
	}
	public List<RentalBooksVo> listupRentalBookHistory(int u_m_no) { 
		return sqlSessionTemplate.selectList("rental.history", u_m_no);
	}
	public int requestHopeBookForm(HopeBookVo hopeBookVo) {		
		return sqlSessionTemplate.insert("userbook.insertHope", hopeBookVo);
	}

}

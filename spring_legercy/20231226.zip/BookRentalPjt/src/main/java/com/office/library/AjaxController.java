package com.office.library;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.office.library.book.BookVo;

@RestController
public class AjaxController {
	private static final Logger logger = LoggerFactory.getLogger(AjaxController.class);
	
/**
 * @ResponseBocy
 * String 이면 문자열
 * map으로 객체 전달
 * map형식의 여러 데이터를 전달  ResponseEntity
 *  
 */
	@GetMapping("/home/sendData1")
	public String sendData1() {
		logger.info("데이터 없이 호출");
		return "success";
	}
	
	@GetMapping("/home/sendData2")
	public String sendData2(
//			@RequestParam String name,
//			@RequestParam int age,
//			@RequestParam String job
			@RequestParam Map<String, Object> map
			) {		
//		logger.info(name);
//		logger.info(age+"");
//		logger.info(job);
		for(Entry<String, Object> entry : map.entrySet()) {
			logger.info(entry.getKey());
		}
		return "success";
	}
	
	@GetMapping("/home/sendData3_1")
	public Map<String, Object> sendData3_1(
			@RequestParam Map<String, Object> map
			) {

		for(Entry<String, Object> entry : map.entrySet()) {
			logger.info(entry.getKey());
		}
	
		
		BookVo b1 =  new BookVo();
		b1.setB_name("책1"); b1.setB_publisher("출판사1");
		
		BookVo b2 =  new BookVo();
		b2.setB_name("책2"); b2.setB_publisher("출판사2");
		
		Map<String, Object> m = new HashMap<String, Object>();
		m.put("abc", 10);m.put("object1", b1);m.put("object2", b2);
		
		return m;
	}
	
	@GetMapping("/home/sendData3_2")
	public Map<String, Object> sendData3_2(
			@RequestParam Map<String, Object> map
			) {

		logger.info(map.get("timedata").toString());		
	
		
		BookVo b1 =  new BookVo();
		b1.setB_name("책1"); b1.setB_publisher("출판사1");
		
		BookVo b2 =  new BookVo();
		b2.setB_name("책2"); b2.setB_publisher("출판사2");
		
		Map<String, Object> m = new HashMap<String, Object>();
		m.put("abc", 10);m.put("object1", b1);m.put("object2", b2);
		
		return m;
	}
	@GetMapping("/home/sendData3_3")
	public Map<String, Object> sendData3_3(
			@RequestParam Map<String, Object> map
			) {
		logger.info(map.toString());
		for(Entry<String, Object> entry : map.entrySet()) {
			logger.info(entry.getKey()+" " + entry.getValue());	
			
		}
	
		
		BookVo b1 =  new BookVo();
		b1.setB_name("책1"); b1.setB_publisher("출판사1");
		
		BookVo b2 =  new BookVo();
		b2.setB_name("책2"); b2.setB_publisher("출판사2");
		
		Map<String, Object> m = new HashMap<String, Object>();
		m.put("abc", 10);m.put("object1", b1);m.put("object2", b2);
		
		return m;
	}
}

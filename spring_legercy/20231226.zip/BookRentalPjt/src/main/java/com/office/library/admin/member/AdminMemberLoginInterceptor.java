package com.office.library.admin.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class AdminMemberLoginInterceptor 
	extends HandlerInterceptorAdapter {

	// 로그인 상태 체크
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		HttpSession session =  request.getSession();
		if(session != null) {
			Object object =  session.getAttribute("loginedAdminMemberVo");
			if(object != null)
				return true;
		}
		response.sendRedirect(request.getContextPath()+"/admin/member/loginForm");
		return false;
		
	}
	
}

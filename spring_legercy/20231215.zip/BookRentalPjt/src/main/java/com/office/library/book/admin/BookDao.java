package com.office.library.book.admin;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.office.library.book.BookVo;

@Component
public class BookDao {
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public boolean isISBN(String b_isbn) {
		return (Integer)sqlSessionTemplate.selectOne("book.selectByIsbn", b_isbn) > 0;
		
	}

	public int insertBook(BookVo bookVo) {
		return sqlSessionTemplate.insert("book.insertbook", bookVo);
		
	}

	public List<BookVo> searchBookConfirm(String b_name) {
		return sqlSessionTemplate.selectList("book.searchbook", b_name);
		
	}

}

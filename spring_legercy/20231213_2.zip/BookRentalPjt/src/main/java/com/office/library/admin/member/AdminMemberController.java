package com.office.library.admin.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/member")
public class AdminMemberController {
	@Autowired
	private AdminMemberService adminMemberService;
	
	
	@GetMapping(value = "createAccountForm")
	public String  createAccountForm( ) {
		String nextPage = "admin/member/create_account_form";
		return nextPage;
	}
	
	@PostMapping(value = "createAccountConfirm")
	public String createAccountConfirm(AdminMemberVo adminMemberVo) {		
		int result = adminMemberService.createAccountConfirm(adminMemberVo);
		return null;
	}
	
	
	
}
package com.office.library.admin.member;

import org.springframework.stereotype.Component;

@Component
public class AdminMemberDao {

	public int createAccountConfirm(AdminMemberVo adminMemberVo) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean isAdminMember(String a_m_id) {
		// TODO Auto-generated method stub
		return false;
	}

	public int insertAdminAccount(AdminMemberVo adminMemberVo) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
}

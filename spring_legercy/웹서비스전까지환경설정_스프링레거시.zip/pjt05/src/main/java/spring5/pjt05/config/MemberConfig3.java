package spring5.pjt05.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import spring5.pjt05.DBConnectionInfo;
import spring5.pjt05.dao.StudentDao;
import spring5.pjt05.service.PrintStudentInformationService;
import spring5.pjt05.service.StudentAllSelectService;
import spring5.pjt05.service.StudentRegisterService;
import spring5.pjt05.utils.InitSampleData;

// applicationContext.xml을 대신함
@Configuration
public class MemberConfig3 {

		
	@Bean
	public InitSampleData initSampleData() {
		InitSampleData initSampleData = new InitSampleData();				
		initSampleData.setsAges(new int[] {19,22,20,27,19});
		initSampleData.setsGenders(new char[] { 'M', 'W', 'W', 'M', 'M' });
		initSampleData.setsIds(new String[] { "rabbit", "hippo", "raccoon", "elephant", "lion" });
		initSampleData.setsMajors(new String[] { "English Literature", "Korean Language and Literature",
			"French Language and Literature", "Philosophy", "History", });
		initSampleData.setsNames(new String[]{ "agatha", "barbara", "chris", "doris", "elva" });
		initSampleData.setsNums(new String[]{ "hbs001", "hbs002", "hbs003", "hbs004", "hbs005" });
		initSampleData.setsPws(new String[]{ "96539", "64875", "15284", "48765", "28661" });		
		return initSampleData;
	}	
	
}

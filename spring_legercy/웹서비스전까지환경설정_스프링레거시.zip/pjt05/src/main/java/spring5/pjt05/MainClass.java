package spring5.pjt05;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import spring5.pjt05.config.MemberConfig;
import spring5.pjt05.config.MemberConfig1;
import spring5.pjt05.config.MemberConfig2;
import spring5.pjt05.config.MemberConfig3;
import spring5.pjt05.dao.StudentDao;
import spring5.pjt05.service.PrintStudentInformationService;
import spring5.pjt05.utils.InitSampleData;

public class MainClass {

	public static void main(String[] args) {
		// 스프링 설정파일 초기화 - 로드
		ApplicationContext ctx = new AnnotationConfigApplicationContext(MemberConfig.class);
//		ApplicationContext ctx 
//		= new AnnotationConfigApplicationContext(MemberConfig1.class,MemberConfig2.class,MemberConfig3.class);
		
		// studentDao 객체를 Bean으로 생성하고
		StudentDao dao = ctx.getBean("studentDao", StudentDao.class);

		// 초기화 bean을 할당
		InitSampleData data = ctx.getBean("initSampleData", InitSampleData.class);
		// initSampleData 있는 데이터를 이용해서 studentDao객체를 한개씩 생성한후
		for (int i = 0; i < data.getsAges().length; i++) {

			Student s = new Student(data.getsNums()[i], data.getsIds()[i], data.getsPws()[i], data.getsNames()[i],
					data.getsAges()[i], data.getsGenders()[i], data.getsMajors()[i]);
			// StudentRegisterService의 insert 매소드를 이용해서 데이터를 추가한다.
			dao.insert(s);
		}
		// 모든학생 정보 출력
		PrintStudentInformationService psfs = ctx.getBean("printStudentInformationService",
				PrintStudentInformationService.class);
		psfs.printStudentsInfo();

		// 나머지. 서비스영역도 테스트 delete modify select ...

	}

}

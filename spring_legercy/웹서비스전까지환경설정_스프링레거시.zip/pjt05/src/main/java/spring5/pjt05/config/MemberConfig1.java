package spring5.pjt05.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import spring5.pjt05.DBConnectionInfo;
import spring5.pjt05.dao.StudentDao;
import spring5.pjt05.service.PrintStudentInformationService;
import spring5.pjt05.service.StudentAllSelectService;
import spring5.pjt05.service.StudentRegisterService;
import spring5.pjt05.utils.InitSampleData;

// applicationContext.xml을 대신함
@Configuration
public class MemberConfig1 {

	@Bean
	public StudentDao studentDao() {
		return new StudentDao();
	}
	@Bean
	public StudentRegisterService studentRegisterService(StudentDao studentDao) {
		 return new StudentRegisterService(studentDao);
	}
	
	@Bean
	public StudentAllSelectService studentAllSelectService(StudentDao studentDao) {
		return new StudentAllSelectService(studentDao);
	}
	
	@Bean
	public PrintStudentInformationService printStudentInformationService(StudentAllSelectService studentAllSelectService) {
		return new PrintStudentInformationService(studentAllSelectService);		
	}
}

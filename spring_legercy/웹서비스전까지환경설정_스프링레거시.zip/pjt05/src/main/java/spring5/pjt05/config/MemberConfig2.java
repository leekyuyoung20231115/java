package spring5.pjt05.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import spring5.pjt05.DBConnectionInfo;
import spring5.pjt05.dao.StudentDao;
import spring5.pjt05.service.PrintStudentInformationService;
import spring5.pjt05.service.StudentAllSelectService;
import spring5.pjt05.service.StudentRegisterService;
import spring5.pjt05.utils.InitSampleData;

// applicationContext.xml을 대신함
@Configuration
public class MemberConfig2 {	
	@Bean
	public DBConnectionInfo dev_DBConnectionInfo() {
		DBConnectionInfo dBConnectionInfo = new DBConnectionInfo();
		dBConnectionInfo.setUrl("0.0.0.0");
		dBConnectionInfo.setUserId("admin");
		dBConnectionInfo.setUserPw("0000");
		return dBConnectionInfo;
	}
	@Bean
	public DBConnectionInfo real_DBConnectionInfo() {
		DBConnectionInfo dBConnectionInfo = new DBConnectionInfo();
		dBConnectionInfo.setUrl("1.1.1.1");
		dBConnectionInfo.setUserId("master");
		dBConnectionInfo.setUserPw("1111");
		return dBConnectionInfo;
	}	
	
}

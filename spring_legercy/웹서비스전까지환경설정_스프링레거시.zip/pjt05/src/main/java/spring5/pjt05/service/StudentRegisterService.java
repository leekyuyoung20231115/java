package spring5.pjt05.service;

import spring5.pjt05.dao.StudentDao;

public class StudentRegisterService {

	private StudentDao studentDao;
	public StudentRegisterService(StudentDao studentDao) {
		this.studentDao = studentDao;
	}

}

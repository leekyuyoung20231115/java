package spring5.pjt05.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

// applicationContext.xml을 대신함
@Configuration
@Import({MemberConfig1.class,MemberConfig2.class,MemberConfig3.class})
public class MemberConfig {
	
}

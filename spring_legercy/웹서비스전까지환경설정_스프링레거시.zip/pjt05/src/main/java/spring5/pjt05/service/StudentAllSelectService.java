package spring5.pjt05.service;

import java.util.Map;

import spring5.pjt05.Student;
import spring5.pjt05.dao.StudentDao;


public class StudentAllSelectService {

	private StudentDao studentDao;

	public StudentAllSelectService(StudentDao studentDao) {
		this.studentDao = studentDao;
	}

	public Map<String, Student> allSelect() {
		return studentDao.getStudentDB();
	}

}
package com.office.library.book.user;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.office.library.book.BookVo;
import com.office.library.book.HopeBookVo;
import com.office.library.book.admin.RentalBooksVo;
import com.office.library.user.member.UserMemberVo;

@Controller
@RequestMapping("/book/user")
public class UserBookController {
	@Autowired
	UserBookService userBookService;
	// 도서 검색
	@GetMapping("/searchBookConfirm")
	public String searchBookConfirm(Model model,
			@RequestParam("b_name") String b_name  ) {
		
		List<BookVo> bookVos = userBookService.searchBookConfirm(b_name);
		
		model.addAttribute("bookVos", bookVos);
		return "/user/book/search_book";
	}
	// 검색된 도서 상세보기
	@GetMapping("/bookDetail")
	public String bookDetail(Model model, 
			@RequestParam("b_no") int b_no ) {
		BookVo bookVo = userBookService.bookDetail(b_no);
		model.addAttribute("bookVo", bookVo);
		return "/user/book/book_detail";
	}
	// 도서 대출하기
	@GetMapping("/rentalBookConfirm")
	public String rentalBookConfirm( HttpSession session,
			@RequestParam("b_no") int b_no) {
		int result = userBookService.rentalBookConfirm(b_no);
		if (result <=0)
			return "/user/book/rental_book_ng";
		
		UserMemberVo vo 
			=(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		result = userBookService.insertRentalBook(b_no,vo.getU_m_no());
		if (result <=0)
			return "/user/book/rental_book_ng";
		
		return "/user/book/rental_book_ok";
	}
	// 나의 책장 
	@GetMapping("/enterBookshelf")
	public String enterBookshelf(HttpSession session, Model model) {
		UserMemberVo vo 
		=(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		List< Map<String, String> > rentalBookVos 
		= userBookService.enterBookshelf(vo.getU_m_no());
		
		model.addAttribute("rentalBookVos",rentalBookVos);
		return "/user/book/bookshelf";
	}
	//나의 대출 이력
	@GetMapping("/listupRentalBookHistory")
	public String listupRentalBookHistory(HttpSession session,Model model) {
		int u_m_no = ((UserMemberVo)session.getAttribute("loginedUserMemberVo")).getU_m_no();
		List<RentalBooksVo> rentalBookVos = userBookService.listupRentalBookHistory(u_m_no);
		model.addAttribute("rentalBookVos", rentalBookVos);
		return "/user/book/rental_book_history";
	}
	// 희망도서 요청
	@GetMapping("/requestHopeBookForm")
	public String requestHopeBookForm() {
		return "/user/book/request_hope_book_form";
	}

	@PostMapping("/requestHopeBookForm")
	public String requestHopeBookForm(HttpSession session, HopeBookVo hopeBookVo) {
		String nextPage = "/user/book/request_hope_book_ok";
		int u_m_no = ((UserMemberVo)session.getAttribute("loginedUserMemberVo")).getU_m_no();
		hopeBookVo.setU_m_no(u_m_no);
		int result = userBookService.requestHopeBookForm(hopeBookVo);
		if(result <= 0)
			nextPage = "/user/book/request_hope_book_ng";
		return nextPage;
	}
	
	
}

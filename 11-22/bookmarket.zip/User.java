
public class User extends Person{
	public User(String name, String phone, String address) {
		super(name, phone, address);
	}
}


public class Admin extends Person{
	private String id = "admin";
	private String password = "admin1234";
	public Admin(String name, String phone, String address) {
		super(name, phone, address);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}

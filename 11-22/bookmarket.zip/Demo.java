
public class Demo {

	public static void main(String[] args) {
		SingleTone s1 = SingleTone.getInstance();
		SingleTone s2 = SingleTone.getInstance();
		s1.number = 100;
		System.out.println(s1.number);
		System.out.println(s2.number);

	}

}

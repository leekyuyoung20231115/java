// 모든 객체는 독립적이다.
// 그래서 객체를 만들지 않고
// 클래스의 특정 메소드를 호출하면 항상 동일한 객체 하나만 리턴하게 설계한다.
// getInstance() 메소드를 주로 사용한다.

public class SingleTone {
	private static SingleTone instance = null;
	public int number = 0;
	
	private SingleTone() {} // 외부에서 객체 생성금지
	
	public static SingleTone getInstance(){
		if(instance == null)
			instance = new SingleTone();
		return instance;
		
	}
}

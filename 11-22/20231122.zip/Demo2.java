
public class Demo2 {

	public static void main(String[] args) {
		Staff s = new Staff();
		s.insertRecord("홍길동", "IT", "2023-01-01", 100000000);
		s.displayInfo();
		

	}

}

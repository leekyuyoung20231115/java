// 클래스 생성 - 객체생성
// static - nonStatic
public class Class02 {
	public static void main(String[] args) {
		
	}
}

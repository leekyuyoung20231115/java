
public class TeanAger extends Human{

	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return 500;
	}

	
}

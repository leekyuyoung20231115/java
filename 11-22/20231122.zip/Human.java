
public abstract class Human {
	protected int price = 20000;
	public abstract int getPrice() ;
}

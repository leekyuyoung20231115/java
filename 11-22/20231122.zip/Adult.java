
public class Adult extends Human{

	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return 15000;
	}
	
}

public class Member {
	private String name;
	private String country;
	private int age;
	
	String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	// 일반생성자 맴버 3개를 초기화하는
	public Member() {}  // 디폴트 생성자
	public Member(String name) {
		this.name = name;
	}
	public Member(String name, String country) {
		this(name);
		this.country=country;
	}
	public Member(String name, String country,int age ) {
		this(name,country);
		this.age = age;
	}
	@Override
	public String toString() {
		return "Member [name=" + name + ", country=" + country + ", age=" + age + "]";
	}

	
	
}

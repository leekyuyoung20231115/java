
public class Parents {
	Parents(int a){
		System.out.println("부모의 기본 생성자 호출");
	}
}

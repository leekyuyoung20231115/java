
public class Test02 {

	public static void main(String[] args) {
		String str = "zpiaz";
		int[] indexs = {1,2,0,0,3};
		String result = "";
		for (int i = 0; i < indexs.length; i++) {
			char c = str.charAt(indexs[i]);
			result += c;
		}
		
		System.out.println(result);
	}

}

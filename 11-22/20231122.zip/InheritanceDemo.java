
public class InheritanceDemo {

	public static void main(String[] args) {
		Inheritnace obj = new Inheritnace();
		obj.addition(10, 20);
		obj.subtraction(10, 20);
		obj.multiplication(10, 3);

	}

}

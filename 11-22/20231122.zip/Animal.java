
public class Animal {
	protected int age;
	// 디폴트 생성자
	public Animal() {}
	
	public Animal(int age) {
		this.age = age;
	}
	
	public void sound() {}	
}

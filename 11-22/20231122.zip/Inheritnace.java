
public class Inheritnace extends Calculation{

	public void multiplication(int x, int y) {
		z = x * y;
		System.out.println("두 수의 곱셈 : " + z);
	}
}

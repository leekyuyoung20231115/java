
public class Cat extends Animal{
	public Cat() {
//		super(0);
		this.age = 0;
	}
	public Cat(int age) {
//		super(age);	
		this.age = age;
	}
	
	@Override
	public void sound() {		
		System.out.println("야옹야옹");
	}
	
	// overload
	public void sound(String str) {
		
	}
	
}

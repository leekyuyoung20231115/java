import java.util.Scanner;

public class HumanDemo {

	public static void main(String[] args) {
//		Human h = new Adult();
//		System.out.println(h.getPrice());
//		
//		h = new TeanAger();
//		System.out.println(h.getPrice());
		
//		Human타입의 배열 5개
//		5명입장객에대한 각각의 나이를 입력받아서 - for
//		나이에 대한 객체를 부모타입으로 만들어서
//		배열에 저장하고
//		그리고 배열을 순환하면서 getPrice()함수를 호출해서 총 입장금액을
//		total이라는 변수를 미리 만들어 놓고 누적시켜서 출력한다.
		Human[] enters = new Human[5];
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < enters.length; i++) {
			System.out.print("입장객의 나이는:");
			int age = sc.nextInt();
			if(age > 20)
				enters[i] = new Adult();
			else
				enters[i] = new TeanAger();
		}
		
		// 입장료 계산
		int totalPrice = 0;
		for (int i = 0; i < enters.length; i++) {
			totalPrice += enters[i].getPrice();
		}
		System.out.print("총 입장료는 : " + totalPrice);
		
		
		// 추상화를 객체지향에 프로그램에서 사용하면?
		Human t = new Adult();
		Adult t2 = new Adult();
		
		int p = t.getPrice();
		int p2 = t2.getPrice();

	}

}


public class MemberDemo {

	public static void main(String[] args) {
		Member m = new Member("홍길동", "한국", 20);		
		
		System.out.println(m.getName());

	}

}

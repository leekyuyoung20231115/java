
public class LottoDemo {

	public static void main(String[] args) {
		Lotto lo = new Lotto();
		String lottoNumber = lo.autoLotto(5);
		System.out.println(lottoNumber);
	}

}

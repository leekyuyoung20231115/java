
public class Child extends Parents{
	public Child() {
		super(1);
		System.out.println("자식의 기본 생성자 호출");
	}
}
